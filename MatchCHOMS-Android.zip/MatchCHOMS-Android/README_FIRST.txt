MatCH CHOMS - native Android app (Java, MVVM + Repository, Firebase Auth + Firestore)
=====================================================================================

1. UNZIP this folder (e.g. C:\Users\Student\AndroidProjects\MatchCHOMS-Android).

2. REGISTER THE ANDROID APP IN YOUR EXISTING FIREBASE PROJECT (match-choms)
   Firebase console > Project settings (gear) > General > Your apps > Add app > Android icon
   - Android package name:  com.match.choms     (must be exactly this)
   - App nickname: CHOMS Android      (SHA-1 not needed)
   - Register app > DOWNLOAD google-services.json

3. google-services.json IS ALREADY INCLUDED in the "app" folder (package com.match.choms, project match-choms).
   (If you ever replace it, put the new file in the same place.)
   MatchCHOMS-Android\app\google-services.json     (same folder as app\build.gradle.kts)

4. OPEN IN ANDROID STUDIO
   File > Open > choose the MatchCHOMS-Android folder (the one containing settings.gradle.kts).
   Wait for the Gradle sync (first time downloads ~500 MB; needs internet).
   If Android Studio asks to "Upgrade Android Gradle Plugin", you may accept or click "Don't remind".
   If it says SDK missing: click the link in the message to install Android SDK Platform 35.

5. RUN
   Device Manager > Create device (Pixel, API 34/35) > press the green Run button.
   Sign in with a user that has a profile in Firestore users/{uid}:
   fields name, email, role (admin / coordinator / chw, lowercase), active (boolean true).

6. BUILD THE APK TO SUBMIT
   Build > Build Bundle(s) / APK(s) > Build APK(s) > click "locate".
   File: app\build\outputs\apk\debug\app-debug.apk

7. RUN THE UNIT TESTS (screenshot for your report)
   Right-click app\src\test\java\com\match\choms\ValidatorsTest > Run 'ValidatorsTest'.

FIRESTORE RULES: this app works with the rules you already published for the web app (firestore.rules
is included for reference). CHW queries are filtered by the CHW's UID so the rules allow them.

COMMON PROBLEMS
- "File google-services.json is missing"  -> step 3.
- Login says "no CHOMS profile"           -> create users/{uid} document (step 5).
- "You do not have permission"            -> the user's role/active fields are wrong, or a CHW record
                                             has no chwId / assignedChwId equal to that CHW's UID.
- Sync error about Java version           -> File > Settings > Build Tools > Gradle > Gradle JDK = jbr-17 or newer.

NO ANDROID STUDIO? BUILD THE APK ON GITHUB
1. Push this folder to a GitHub repository (include app/google-services.json, or add its text as a repository
   secret named GOOGLE_SERVICES_JSON: Settings > Secrets and variables > Actions).
2. Actions tab > "Build Android APK" > Run workflow.
3. When it turns green, open the run > Artifacts > MatCH-CHOMS-debug-apk > download, unzip, copy app-debug.apk to the phone.
4. On the phone: open the APK > allow "Install unknown apps" for your file manager/browser > Install.
